import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './App.css';
import FooterComponents from './Components/FooterComponents';
import HeaderComponents from './Components/HeaderComponents';
import ListEmployeeComponent from './Components/ListEmployeeComponent';
import EmployeeComponents from './Components/EmployeeComponents';
import ViewEmployeeComponent from './Components/ViewEmployeeComponent';

function App() {
  return (
    <>
      <BrowserRouter>
        <HeaderComponents />
        <Routes>
          {/* Home Route - Lists all employees */}
          <Route path="/" element={<ListEmployeeComponent />} />

          {/* Employees List Page */}
          <Route path="/employees" element={<ListEmployeeComponent />} />

          {/* Add New Employee Page */}
          <Route path="/add-employee" element={<EmployeeComponents />} />

          {/* Edit Existing Employee Page */}
          <Route path="/edit-employee/:id" element={<EmployeeComponents />} />
          <Route path='/view-employee/:id' element={<ViewEmployeeComponent />} />
        </Routes>
        <FooterComponents />
      </BrowserRouter>
    </>
  );
}

export default App;
