import React, { useEffect, useState } from 'react';
import { listEmployees, getEmployee, deleteEmployee } from '../services/EmployeeServices';
import { useNavigate } from 'react-router-dom';

const ListEmployeeComponent = () => {
    const [employees, setEmployees] = useState([]);
    const navigator = useNavigate();

    useEffect(() => {
        fetchEmployees();
    }, []);

    // Fetch Employees
    const fetchEmployees = () => {
        listEmployees()
            .then((response) => {
                setEmployees(response.data);
            })
            .catch((error) => {
                console.error('Error fetching employees:', error);
            });
    };

    // Add Employee
    const addNewEmployee = () => {
        navigator('/add-employee');
    };

    // Update Employee
    const updateEmployee = (id) => {
        navigator(`/edit-employee/${id}`);
    };

    // View Employee
    const viewEmployee = (id) => {
        navigator(`/view-employee/${id}`);
    };
    

    // Delete Employee
    const deleteEmployeeById = (id) => {
        if (window.confirm('Are you sure you want to delete this employee?')) {
            deleteEmployee(id)
                .then(() => {
                    alert('Employee deleted successfully');
                    fetchEmployees(); // Refresh the list after deleting
                })
                .catch((error) => {
                    console.error('Error deleting employee:', error);
                });
        }
    };

    return (
        <div className='container'>
            <h2>List of Employees</h2>
            <button className='btn btn-primary mb-2' onClick={addNewEmployee}>Add Employee</button>
            <table className='table table-striped table-bordered'>
                <thead>
                    <tr>
                        <th>Employee ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {employees.map((employee) => (
                        <tr key={employee.id}>
                            <td>{employee.id}</td>
                            <td>{employee.firstName}</td>
                            <td>{employee.lastName}</td>
                            <td>{employee.email}</td>
                            <td>
                                <button className='btn btn-info mx-1' onClick={() => updateEmployee(employee.id)}>Update</button>
                                <button className='btn btn-danger mx-1' onClick={() => deleteEmployeeById(employee.id)}>Delete</button>
                                <button className='btn btn-secondary mx-1' onClick={() => viewEmployee(employee.id)}>View</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ListEmployeeComponent;
