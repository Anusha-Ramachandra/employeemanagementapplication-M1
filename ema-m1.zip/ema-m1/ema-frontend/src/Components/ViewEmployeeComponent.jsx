import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getEmployee } from '../services/EmployeeServices';

const ViewEmployeeComponent = () => {
    const { id } = useParams();
    const [employee, setEmployee] = useState(null);

    useEffect(() => {
        getEmployee(id)
            .then((response) => {
                setEmployee(response.data);
            })
            .catch((error) => {
                console.error('Error fetching employee details:', error);
            });
    }, [id]);

    return (
        <div className="container">
            <h2 className="text-center">Employee Details</h2>
            {employee ? (
                <div className="card p-4">
                    <p><strong>ID:</strong> {employee.id}</p>
                    <p><strong>First Name:</strong> {employee.firstName}</p>
                    <p><strong>Last Name:</strong> {employee.lastName}</p>
                    <p><strong>Email:</strong> {employee.email}</p>
                </div>
            ) : (
                <p>Loading employee details...</p>
            )}
        </div>
    );
};

export default ViewEmployeeComponent;
