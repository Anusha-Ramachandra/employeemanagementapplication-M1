import React from 'react'

const FooterComponents = () => {
  return (
    <div>
        <footer className='footer'> 
            <span>All rights reserved 2025 by empmgtapp</span>
        </footer>

    </div>
  )
}

export default FooterComponents
